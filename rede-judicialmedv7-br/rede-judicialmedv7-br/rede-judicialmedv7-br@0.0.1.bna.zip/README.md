# rede-judicialmedv7-br

Rede Blockchain para solicitação de medicamento por via judicial
